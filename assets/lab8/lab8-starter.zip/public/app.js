// Import the functions you need from the SDKs you need
// https://firebase.google.com/docs/web/setup#available-libraries

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-app.js";
import {
    getAuth,
    signInWithPopup,
    signOut,
    GoogleAuthProvider,
    onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/10.9.0/firebase-auth.js";
import {
    getFirestore,
    addDoc,
    getDocs,
    collection,
    query,
    where,
    Timestamp,
} from "https://www.gstatic.com/firebasejs/10.9.0/firebase-firestore.js";


// Select DOM elements
const signInBtn = document.getElementById("sign-in-btn");
const signOutBtn = document.getElementById("sign-out-btn");
const userDetailsEl = document.getElementById("user-details");

const createEntryBtn = document.getElementById("create-entry-btn");
const entryListEl = document.getElementById("entry-list");
const newEntryInput = document.getElementById("new-entry-text");


// Variables that maintain state
let user = null; // current user or null if not signed in


/**
 * Firebase Setup
 */

//////// QUESTION 1: Configuring your Firebase Project ////////
const firebaseConfig = {
    /* YOUR CONFIG HERE */
};
//////// END OF QUESTION 1 ////////

const app = initializeApp(firebaseConfig);


/**
 * Authentication
 */

const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// When the sign-in button is clicked, the pop-up window will appear for users to sign in via Google.
signInBtn.addEventListener('click', () => signInWithPopup(auth, provider));
signOutBtn.addEventListener('click', () => signOut(auth, provider));


/**
 * Database
 */

const db = getFirestore(app);

async function loadUserEntries(user) {
    //////// QUESTION 3: Find all documents related to the query you are making below! (Hint: Check the homework spec) ////////
    const q = query(collection(db, "entries"), where("uid", "==", user.uid));
    // const querySnapshot = /* YOUR CODE HERE */;

    // Helper Code for Testing: This prints all the documents/entries you found and their IDs in the console! (Browser Developer Tools)
    querySnapshot.forEach((doc) => {
        console.log(doc.id, " => ", doc.data());
    });
    //////// END OF QUESTION 3 ////////

    entryListEl.innerHTML = querySnapshot.docs.map((doc) => {
        const { timestamp, entry } = doc.data();
        const prettyTime = timestamp.toDate().toLocaleString();

        // note: this is unsafe in general, as entry is not escaped/sanitized - it might contain html tags!
        return `<li>${prettyTime}: ${entry}</li>`;
    }).join("\n");
};


/**
 * UI handlers
 */

// function passed to onAuthStateChanged runs when user signs in or out
onAuthStateChanged(auth, async (newUser) => {
    user = newUser;

    if (user) {
        userDetailsEl.innerHTML = `<h3>Hello ${user.displayName}!</h3> <p>User ID: ${user.uid}</p>`;
        await loadUserEntries(user);
        document.body.classList.add("signed-in");
    } else {
        //////// QUESTION 2: What happens when a user signs out? (The previous lines are a hint!) ////////
        /* YOUR CODE HERE */
        //////// END OF QUESTION 2 ////////
    }

    document.body.classList.remove("loading");
});

createEntryBtn.addEventListener('click', async () => {
    //////// QUESTION 4: Add an entry in the database! (Hint: Check the homework spec) ////////
    let timestamp = Timestamp.now();

    // const newEntryRef = /* YOUR CODE HERE */;

    console.log("Document written at", timestamp.toDate(), "with ID:", newEntryRef.id);
    //////// END OF QUESTION 4 ////////

    newEntryInput.value = "";
    await loadUserEntries(user);
});
