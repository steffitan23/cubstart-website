
const newTodo = document.getElementById('new-todo');
const todoList = document.getElementById('todo-list');
const addBtn = document.getElementById('add-btn');
addBtn.addEventListener('click', addTask);

updateTasks()

async function postRequest(url, jsonData) {
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(jsonData)
  };
  const response = await fetch(url, options);
  const data = await response.json();
  return data
}

async function getRequest(url) {
  const response = await fetch(url);
  const data = await response.json();
  return data
}

async function updateTasks() {
  const url = "http://localhost:3000/tasks"
  const tasks = await getRequest(url)

  tasks.forEach(task => {
    const newDiv = document.createElement("div");
    const newTask = document.createElement("li");

    if (!task.completed) {
      var xBtn = document.createElement('button');
      xBtn.className = 'x-button'
      xBtn.textContent = 'X';
      xBtn.onclick = () => completeTask(task._id, newDiv, xBtn)
    } else {
      newDiv.className = 'completed-task';
    }
    
    newTask.textContent = task.description;
    newDiv.appendChild(newTask)
  
    if (!task.completed) {
      newDiv.appendChild(xBtn)
    }
    todoList.appendChild(newDiv)
    
  });
}

async function addTask() {
  const taskToBeAdded = { description: newTodo.value };
  const url = "http://localhost:3000/new";
  const created = postRequest(url, taskToBeAdded);

  const newDiv = document.createElement("div");
  const newTask = document.createElement("li");
  var xBtn = document.createElement('button');

  xBtn.className = 'x-button'
  newTask.textContent = taskToBeAdded.description;
  xBtn.textContent = 'X';
  xBtn.onclick = () => completeTask(created._id, newDiv, xBtn)

  newDiv.appendChild(newTask)
  newDiv.appendChild(xBtn)
  todoList.appendChild(newDiv)
  newTodo.value = ""
}

async function completeTask(id, div, btn) {
  div.className = "completed-task";
  btn.remove();
  console.log(id)
  const response = await getRequest('http://localhost:3000/complete/' + id)
  return response
}

