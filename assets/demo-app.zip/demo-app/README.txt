1. Do "npm install" in terminal
2. Put your MongoDB url to connect in server.js.
3. Run by doing 'node server.js' in terminal