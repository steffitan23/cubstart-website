const express = require('express');
const app = express();
const mongoose = require('mongoose');

const bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

main().catch(err => console.log(err));

//Fill in your URL here
async function main() {
  await mongoose.connect('YOURMONGODBURLHERE');
}

const taskSchema = new mongoose.Schema({
  description: String,
  completed: Boolean
});

const Task = mongoose.model('Task', taskSchema)

app.get('/', (req, res) => {
  res.sendFile(__dirname + "/index.html")
}); // http://localhost:3000/

app.post('/new', async (req, res) => {
    const newTask = new Task({description:req.body.description, completed:false});
    await newTask.save()
    res.send(newTask)
});

app.get('/tasks', async (req,res) => {
    const foundTasks = await Task.find();
    res.send(foundTasks)
})

app.get('/complete/:id', async (req,res) => {
  const id = req.params.id;
  const doc = await Task.findById(id)
  doc.completed = true;
  await doc.save();
})


app.use(express.static("./public"))

app.listen(3000, function() {
  console.log('Listening on http://localhost:3000');
});