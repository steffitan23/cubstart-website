
function Comment(props) {
  const { text } = props;

  return <p className="comment_text">{text}</p>;
}

export default Comment;
