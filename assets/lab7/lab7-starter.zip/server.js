const express = require('express')
const mongoose = require('mongoose')
const asyncHandler = require('express-async-handler')
const bodyParser = require('body-parser')

const app = express()


// QUESTION: add your connection URL
const dbConnectionUri = 'mongodb+srv://...'
const dbName = 'petfinder'

// QUESTION: make a schema for a pet
const petSchema = // ...

// QUESTION: make a mongoose model from it
// note: the first parameter should match the model name (capitalized, not plural).
//       mongoose automatically converts it to a plural collection name (i.e. Cat -> cats)
const Pet = // ...


// parses JSON bodies in POST/PUT requests and put then in req.body
app.use(bodyParser.json())

// handler to serve the index.html file
app.get('/', (req, res) => res.sendFile(__dirname + '/index.html'))


// QUESTION: add a handler to get pets
app.get('/pets', /* ... */)

// QUESTION: add a handler to create a pet: POST /pets
// ...


// function to connect to database and start the server
async function start() {
    await mongoose.connect(dbConnectionUri, { dbName })

    console.log(`Connected to the mongoDB database '${dbName}'`)

    app.listen(3000, () => {
        console.log('Server listening on port 3000')
    })
}

start()
