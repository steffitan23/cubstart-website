// import { MemoryGame } from './MemoryGame';

function App() {
  return (
    <div className="App container">
      {/* <MemoryGame /> */}
    </div>
  );
}

export default App;
