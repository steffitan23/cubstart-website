// Feel free to go ham and add more jokes :D
const jokesArray = [
    "What’s the best thing about Switzerland? I don’t know, but the flag is a big plus.",
    "Why do we tell actors to “break a leg? Because every play has a cast.",
    "Did you hear about the actor who fell through the floorboards? He was just going through a stage.",
    "Did you hear about the claustrophobic astronaut? He just needed a little space.",
    "How do you keep a bagel from getting away? Put lox on it.",
    "Did you hear the one about the guy with the broken hearing aid? Neither did he.",
    "Why are skeletons so calm? Because nothing gets under their skin.",
    "What's the worst thing about ancient history class? The teachers tend to Babylon.",
    "I used to work for a soft drink can crusher. It was soda pressing.",
    "What did celery say when he broke up with his girlfriend? She wasn't right for me, so I really don't carrot all.",
    "How many optometrists does it take to change a light bulb? 1 or 2? 1... or 2?"
]

function getRandomInt(max) {
    /* Returns a random integer from 0 (inclusive) to max (exclusive) */
    // TODO
}

function replaceJoke() {
    /* Replaces the joke on screen with a random one from jokesArray
        whenever the button is clicked */
    
    // Select a random quote
    const randInt = // TODO
    const randJoke = // TODO

    // Replace the text in the "joke" div element with the chosen joke
    // TODO
}

// Add a onclick event handler for the button
let button = // TODO
button.addEventListener("click", replaceJoke);