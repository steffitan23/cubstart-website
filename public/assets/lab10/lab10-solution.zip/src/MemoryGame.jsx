import { useState } from 'react';
import Card from './Card';
import { generateBoard } from './utils';

function MemoryGame() {
  const [board, setBoard] = useState(generateBoard());
  const [visiblePos, setVisiblePos] = useState([]);
  const [matchedSymbols, setMatchedSymbols] = useState([]);

  const reset = () => {
    setBoard(generateBoard());
    setMatchedSymbols([]);
    setVisiblePos([]);
  };

  return (
    <div>
      <h1>Match Cards</h1>

      <div className="board">
        {board.map((symbol, index) => {
          const isVisible = visiblePos.includes(index);
          const isMatched = matchedSymbols.includes(symbol);

          const onCardClicked = () => {
            if (isMatched || (isVisible && visiblePos.length < 2)) {
              // skip if card is already matched or visible
              return;
            }

            if (visiblePos.length === 1) {
              if (board[visiblePos[0]] === board[index]) {
                // card matched!
                setMatchedSymbols([...matchedSymbols, board[index]]);
                setVisiblePos([]);
              } else {
                // show this card too
                setVisiblePos([...visiblePos, index]);
              }
            } else {
              // if 0 or 2 cards are already visible, show this card
              setVisiblePos([index]);
            }
          }

          return (
            <Card
              key={index}
              symbol={symbol}
              isVisible={isVisible}
              isMatched={isMatched}
              onClick={onCardClicked}
            />
          );
        })}
      </div>

      <button style={{ marginTop: '24px' }} onClick={reset}>
        Restart
      </button>
    </div>
  );
}

export default MemoryGame;
