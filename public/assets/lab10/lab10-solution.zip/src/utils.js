
export function generateBoard() {
  const chars = ['#', '$', '!', '%', '&', '*', '@', '^'];

  const positions = [...Array(16).keys()];

  const shuffled = positions
    .map((value) => ({ value, sort: Math.random() }))
    .sort((a, b) => a.sort - b.sort)
    .map(({ value }) => value);

  const board = new Array(16).fill(0);

  for (let i = 0; i < 8; i++) {
    board[shuffled[i * 2]] = chars[i];
    board[shuffled[i * 2 + 1]] = chars[i];
  }

  return board;
}
