function Card({ symbol, onClick, isVisible, isMatched }) {
  return (
    <div className={`card ${isMatched ? 'matched' : ''}`} onClick={onClick}>
      {isVisible || isMatched ? symbol : ''}
    </div>
  );
}

export default Card;
