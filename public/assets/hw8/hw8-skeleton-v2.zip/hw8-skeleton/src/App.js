import './styles/App.css';
import './styles/components.css';
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function App() {

  const [newComment, setNewComment] = useState("")
  const [comments, setComments] = useState([])

  const makeANewComment = () => {
    const new_comments_array = comments
    new_comments_array.push(newComment)
    setComments(new_comments_array)
    setNewComment("")
    console.log(comments)
  }

  const changeNewCommentValue = (comment_value) => {
    /* Q2: How do we update newComment? Set it equal to comment_value. */
    /* YOUR CODE HERE */
  }
  return (
    <div className="App">
     
      <h3 className="app_topHeader">This is my Social Media Post</h3>

      <div className="app_commentsHeader">Comments:</div>

      {comments}

      {comments.map((comment) => {

        return (
          <div>
            <p>{comment}</p>
          </div>
        )

      })}

      <input className="app_input"
      onChange={(e) => {changeNewCommentValue(e.target.value)}}value={newComment} placeholder="Write a Comment Here!" />
    
      <div style={{"clear":"both"}}></div>
      <button className="app_topButton"
      // Q1: What function should go in here? Call it with ZERO parameters.
      onClick={() => /* YOUR CODE HERE */ }>Add Comment!</button> 

      <div style={{"clear":"both"}}></div>

      <Link to="/profile/1">
      <button className="app_bottomButton">
      Go To My Profile
      </button>
    </Link>

    </div>
  );
}

export default App;
