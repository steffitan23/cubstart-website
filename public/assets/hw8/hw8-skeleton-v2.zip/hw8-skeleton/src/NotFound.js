
function NotFound() {
  return (
    <div className="App">
      <h3 className="notFound_title">Sorry, I couldn't find this page :(</h3>
      <img className="notFound_img" src="https://cdn-icons-png.flaticon.com/512/2731/2731811.png"/>
    </div>
  );
}

export default NotFound;
